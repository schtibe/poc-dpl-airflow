import logging
from typing import Any

from .generate_nodes import Node

logger = logging.getLogger("pipeline_tooling")


def apply_nodes(nodes: list[Node], data: dict | None = None, data2: dict | None = None) -> Any:
    if len(nodes) == 0:
        logger.info("No nodes to apply")
        return data

    logger.info(f"Applying nodes: {nodes}")

    if data is None:
        # here we're dealing with the first node in the tree. There can't be any data yet, so we're
        # calling the first node without passing in data
        first_node = nodes[0]

        if first_node["type"] == "ForkNode":
            logger.info(f"Applying ForkNode (first node): {first_node}")
            left = apply_nodes(first_node["left"], data)
            right = apply_nodes(first_node["right"], data)

            data = apply_nodes(
                nodes=first_node["final"],
                data=left,
                data2=right,
            )
        else:
            logger.info(f"Applying first node: {first_node} with args: {first_node['args']}")
            # if we don't pass in any data, then the first
            # node has to be the one reading it
            data = (
                first_node["func"](**first_node["args"])
                if first_node["args"] and len(first_node["args"]) > 0
                else first_node["func"]()
            )

        # removing the first node
        nodes = nodes[1:]

    for idx, node in enumerate(nodes):
        if node["type"] == "ForkNode":
            logger.info(f"Applying ForkNode: {node}")
            # recurse or something
            left = apply_nodes(node["left"], data)
            right = apply_nodes(node["right"], data)

            data = apply_nodes(
                nodes=node["final"],
                data=left,
                data2=right,
            )
        else:
            logger.info(f"Applying node: {node} with args: {node['args']}")
            if data2 is not None and idx == 0:
                # only if it's the first entry in the chain that we can have a node which supports
                # two data sets
                data = node["func"](
                    data, data2, **(node["args"] if node["args"] and len(node["args"]) > 0 else {})
                )
            else:
                data = node["func"](
                    data, **(node["args"] if node["args"] and len(node["args"]) > 0 else {})
                )

    return data
