import logging

from pipeline_tooling import parser

from .Node import Node, SimpleNode

logger = logging.getLogger("pipeline_tooling")


def generate_parser(node_name: str, node_args: dict) -> Node:
    """Generate an parser node function."""

    logger.info(f"Going to generate parser for node: {node_name}")

    return SimpleNode(type="SimpleNode", func=getattr(parser, node_name), args=node_args)
