import logging

from pipeline_tooling import writer

from .Node import Node, SimpleNode

logger = logging.getLogger("pipeline_tooling")


def generate_writer(node_name: str, node_args: dict) -> Node:
    logger.info(f"Going to generate writer for node: {node_name}")

    logger.info(f"Node: {node_name}, node_args: {node_args}")

    return SimpleNode(type="SimpleNode", func=getattr(writer, node_name), args=node_args)
