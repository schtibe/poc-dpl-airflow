# test_interpolate_params.py

from pipeline_tooling.from_nodes.generate_nodes import interpolate_params


def test_interpolate_params_basic():
    """Test basic interpolation with a single parameter"""
    node_args = {"file_key": "{{ file_key }}"}
    params = {"file_key": "vnut12.lssw.202608240800.tre200px.csv"}

    result = interpolate_params(node_args, params)

    assert result == {"file_key": "vnut12.lssw.202608240800.tre200px.csv"}


def test_interpolate_params_multiple():
    """Test interpolation with multiple parameters"""
    node_args = {
        "file_key": "{{ file_key}}",
        "output_path": "{{output_path }}",
        "format": "{{format}}",
    }
    params = {
        "file_key": "vnut12.lssw.202608240800.tre200px.csv",
        "output_path": "/tmp/output",
        "format": "csv",
    }

    result = interpolate_params(node_args, params)

    assert result == {
        "file_key": "vnut12.lssw.202608240800.tre200px.csv",
        "output_path": "/tmp/output",
        "format": "csv",
    }


def test_interpolate_params_no_match():
    """Test when no parameter match occurs"""
    node_args = {"file_key": "{{file_key}}", "other": "value"}
    params = {"file_key": "vnut12.lssw.202608240800.tre200px.csv"}

    result = interpolate_params(node_args, params)

    # Only the file_key should be interpolated
    assert result == {"file_key": "vnut12.lssw.202608240800.tre200px.csv", "other": "value"}


def test_interpolate_params_no_template():
    """Test when no template strings are present"""
    node_args = {"file_key": "value", "other": "another_value"}
    params = {"file_key": "vnut12.lssw.202608240800.tre200px.csv"}

    result = interpolate_params(node_args, params)

    assert result == {"file_key": "value", "other": "another_value"}


def test_interpolate_params_empty_params():
    """Test with empty parameters dictionary"""
    node_args = {"file_key": "{{file_key}}"}
    params = {}

    result = interpolate_params(node_args, params)

    assert result == {"file_key": "{{file_key}}"}


def test_interpolate_params_missing_parameter():
    """Test when parameter is not found in params"""
    node_args = {"file_key": "{{file_key}}"}
    params = {"other": "value"}

    result = interpolate_params(node_args, params)

    assert result == {"file_key": "{{file_key}}"}
