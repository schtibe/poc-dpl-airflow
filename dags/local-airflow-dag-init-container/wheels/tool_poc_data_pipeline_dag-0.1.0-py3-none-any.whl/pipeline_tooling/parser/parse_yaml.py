import logging
import typing

import yaml

logger = logging.getLogger("pipeline_tooling")


def parse_yaml(stream: typing.IO[bytes]) -> dict:
    logger.info("Going to parse yaml")

    table = yaml.safe_load(stream)
    stream.close()
    return table
