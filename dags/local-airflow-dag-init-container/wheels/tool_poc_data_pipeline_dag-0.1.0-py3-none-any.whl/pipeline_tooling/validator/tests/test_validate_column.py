# ruff: noqa: E731 PT011

import pyarrow as pa
import pytest

from pipeline_tooling.validator.validate_column import validate_column


def test_validate_column_passes_positive_values():
    data = pa.Table.from_pydict({"value": [1, 2, 3]})
    cb = lambda x: x > 0

    result = validate_column(data, "value", cb)
    assert isinstance(result, pa.Table)


def test_validate_column_fails_on_negative_value():
    data = pa.Table.from_pydict({"value": [1, -1, 3]})
    cb = lambda x: x > 0

    with pytest.raises(ValueError) as exc:
        validate_column(data, "value", cb)
    msg = str(exc.value)
    assert "value=-1" in msg


def test_validate_column_raises_on_missing_column():
    data = pa.Table.from_pydict({"other": [1, 2, 3]})
    cb = lambda x: True

    with pytest.raises(ValueError) as exc:
        validate_column(data, "value", cb)
    assert "Column 'value' not found" in str(exc.value)


def test_validate_column_raises_on_wrong_type():
    with pytest.raises(TypeError):
        validate_column("not a table", "value", lambda x: True)


def test_validate_column_bubbles_exceptions_from_callback():
    data = pa.Table.from_pydict({"value": [1, 2, 3]})

    def cb(x):
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError) as exc:
        validate_column(data, "value", cb)
    assert "boom" in str(exc.value)
