# ruff: noqa: PT011
#
import pyarrow as pa
import pytest

from pipeline_tooling.validator.validate_schema import validate_schema


def _make_schema() -> pa.Schema:
    return pa.schema(
        [
            pa.field("id", pa.int64(), nullable=False),  # required
            pa.field("name", pa.string(), nullable=True),  # optional
            pa.field("score", pa.float64(), nullable=True),  # optional
            pa.field("flag", pa.bool_(), nullable=False),  # required
        ]
    )


def _make_data() -> pa.Table:
    return pa.Table.from_pydict(
        {
            "id": [1, 2],
            "name": ["Alice", "Bob"],
            "score": [0.5, None],
            "flag": [True, False],
        }
    )


def test_validate_schema_passes_matching_schema():
    data = _make_data()
    schema = _make_schema()
    result = validate_schema(data, schema)

    assert isinstance(result, pa.Table)


@pytest.mark.skip
def test_validate_schema_raises_on_type_mismatch():
    data = _make_data()
    # Change a field type in the expected schema to trigger mismatch
    wrong_schema = pa.schema(
        [
            pa.field("id", pa.string(), nullable=False),  # string instead of int64
            pa.field("name", pa.string(), nullable=True),
            pa.field("score", pa.float64(), nullable=True),
            pa.field("flag", pa.bool_(), nullable=False),
        ]
    )
    with pytest.raises(ValueError) as exc:
        validate_schema(data, wrong_schema)
    assert "Schema mismatch" in str(exc.value)


def test_validate_schema_raises_on_non_table_input():
    schema = _make_schema()
    with pytest.raises(TypeError):
        validate_schema({"not": "a table"}, schema)


def test_validate_schema_raises_on_order_mismatch():
    data_in_diff_order = pa.Table.from_pydict(
        {
            "name": ["Alice", "Bob"],
            "id": [1, 2],
            "score": [0.5, 0.9],
            "flag": [True, False],
        }
    )
    # Original order is id, name, score, flag
    expected_schema = _make_schema()
    with pytest.raises(ValueError):
        validate_schema(data_in_diff_order, expected_schema)
