# ruff: noqa: PT011

import pyarrow as pa
import pytest

from pipeline_tooling.validator.validate_uniqueness import validate_uniqueness


def test_validate_uniqueness_single_column():
    data = pa.Table.from_pydict({"id": [1, 2, 3]})
    result = validate_uniqueness(data, "id")
    assert isinstance(result, pa.Table)


def test_validate_uniqueness_single_column_fails_on_duplicates():
    data = pa.Table.from_pydict({"id": [1, 2, 1]})
    with pytest.raises(ValueError) as exc:
        validate_uniqueness(data, "id")
    assert "following duplicates: [1]" in str(exc.value)


def test_validate_uniqueness_multiple_columns_pass():
    # Individual columns may have duplicates but combined they are unique
    data = pa.Table.from_pydict(
        {
            "a": [1, 1, 2],
            "b": [1, 2, 1],
        }
    )
    result = validate_uniqueness(data, ["a", "b"])
    assert isinstance(result, pa.Table)


def test_validate_uniqueness_multiple_columns_fails_on_combined_duplicates():
    data = pa.Table.from_pydict(
        {
            "a": [1, 1, 1],
            "b": [1, 1, 2],
        }
    )
    with pytest.raises(ValueError) as exc:
        validate_uniqueness(data, ["a", "b"])
    assert "['a', 'b']" in str(exc.value) or "a" in str(exc.value)
    assert "following duplicates: [(1, 1)]" in str(exc.value)


def test_validate_uniqueness_ignore_none():
    data = pa.Table.from_pydict({"id": [1, 2, None, None]})
    result = validate_uniqueness(data, "id", ignore_empty=True)
    assert isinstance(result, pa.Table)


def test_validate_uniqueness_ignore_empty_raises_when_multiple_none():
    data = pa.Table.from_pydict({"id": [1, 2, None, None]})
    with pytest.raises(ValueError):
        validate_uniqueness(data, "id", ignore_empty=False)


def test_validate_uniqueness_ignore_empty_string():
    data = pa.Table.from_pydict({"id": ["CHE", "ABC", "", ""]})
    result = validate_uniqueness(data, "id", ignore_empty=True)
    assert isinstance(result, pa.Table)
