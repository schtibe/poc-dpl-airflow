import logging

import pyarrow as pa

logger = logging.getLogger("pipeline_tooling")


def validate_schema(data: pa.Table, schema: pa.Schema) -> pa.Table:
    """Validate the schema of a py Arrow Dataframe

    Validate the schema of a py Arrow Dataframe with a pyArrow schema definition

    The problem lies in how pyArrow validates the data. When looking at the test data, a table that
    has an inferred schema where some columns are nullable and others are not, this validation
    can't be performed correctly.

    Probably we want some pydantic schema validation instead

    Args:
        data: The py Arrow Table to validate
        schema: The expected schema
    Returns:
        The validated py Arrow Table
    """

    # Ensure input is a PyArrow Table
    if not isinstance(data, pa.Table):
        raise TypeError(f"df must be a pyarrow.Table, got {type(data).__name__}")

    logger.info(f"Validating schema for table {data.take([0, min(data.num_rows - 1, 5)])}...")

    try:
        data = data.cast(schema)
    except pa.ArrowInvalid as e:
        raise ValueError(f"Schema mismatch: {e}") from e

    return data
