import collections
import logging

import pyarrow as pa
import pyarrow.compute as pc

logger = logging.getLogger("pipeline_tooling")


def validate_uniqueness(
    data: pa.Table, columns: str | list[str], ignore_empty: bool = True
) -> pa.Table:
    """
    Validate that the specified columns are unique in the data.

    If more than one column is specified, all columns together must be unique.
    If ignore_empty is True, empty values will be ignored when validating uniqueness, but only in case of
    single column validation.

    Args:
        data (pa.Table): The data to validate.
        columns (str | list[str]): The column(s) to validate.
        ignore_empty (bool, optional): Whether to ignore empty values. Defaults to True. Can only
        be used when columns is a single column.

    Raises:
        ValueError: If any of the specified columns are not unique.
    """
    if isinstance(columns, str):
        logger.info("Validating uniqueness of single column %s", columns)
        column_data = data[columns]

        if ignore_empty:
            logger.info("Dropping empty values from column %s", columns)
            if data[columns].type == pa.string():
                # filter out empty strings
                column_data = column_data.filter(pc.not_equal(column_data, ""))  # type: ignore[attr-defined]  # ty: ignore[unresolved-attribute]

            # filter out null values
            column_data = column_data.drop_null()

        unique_values = column_data.unique().to_pylist()

        if len(unique_values) != len(column_data):
            duplicates = [
                id
                for id, count in collections.Counter(column_data.to_pylist()).items()  # noqa: A001
                if count > 1
            ]
            raise ValueError(
                f"Column {columns} is not unique. It contains following duplicates: {duplicates}"
            )
    else:
        logger.info("Validating uniqueness of multiple columns together %s", columns)
        values = []
        for column in columns:
            column_values = data[column].to_pylist()
            values.append(column_values)

        # strict makes sense her as we want to ensure that both columns used for
        # the uniqueness check are fully present in the data
        combined_values = list(zip(*values, strict=False))
        unique_values = list(set(combined_values))

        if len(list(unique_values)) != len(data):
            # extract the non-unique values and raise an error
            duplicates = [
                id
                for id, count in collections.Counter(combined_values).items()  # noqa: A001
                if count > 1
            ]
            raise ValueError(
                f"Columns {columns} are not unique. It contains following duplicates: {duplicates}"
            )

    return data
